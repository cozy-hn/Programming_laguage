from ft_parser import FT_Parser

def main():
	FT_Parser().start()

if __name__ == "__main__":
	main()
 